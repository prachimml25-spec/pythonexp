from flask import Flask, render_template, request, jsonify, send_file
from pathlib import Path
from datetime import datetime
import json, uuid, io, zipfile, threading, webbrowser

app = Flask(__name__)
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
DB_FILE = DATA_DIR / "filesystem.json"
DATA_DIR.mkdir(exist_ok=True)

def starter_fs():
    now = datetime.now().isoformat(timespec="seconds")
    return {
        "id": "root", "name": "My Computer", "type": "folder", "parent": None,
        "created": now, "modified": now, "children": [
            {"id": "docs", "name": "Documents", "type": "folder", "parent": "root", "created": now, "modified": now, "children": [
                {"id": "welcome", "name": "Welcome.txt", "type": "file", "parent": "docs", "created": now, "modified": now, "content": "Welcome to the File Directory Structure Simulator!\\n\\nCreate folders and files, organize them, search, and explore the directory tree."}
            ]},
            {"id": "projects", "name": "Projects", "type": "folder", "parent": "root", "created": now, "modified": now, "children": [
                {"id": "python", "name": "Python", "type": "folder", "parent": "projects", "created": now, "modified": now, "children": []}
            ]},
            {"id": "images", "name": "Images", "type": "folder", "parent": "root", "created": now, "modified": now, "children": []}
        ]
    }

def save_fs(tree):
    DB_FILE.write_text(json.dumps(tree, indent=2, ensure_ascii=False), encoding="utf-8")

def load_fs():
    if not DB_FILE.exists():
        tree = starter_fs()
        save_fs(tree)
        return tree
    try:
        return json.loads(DB_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        tree = starter_fs()
        save_fs(tree)
        return tree

def find_node(node, node_id):
    if node["id"] == node_id:
        return node
    if node["type"] == "folder":
        for child in node.get("children", []):
            found = find_node(child, node_id)
            if found:
                return found
    return None

def find_parent(node, node_id):
    if node["type"] == "folder":
        for child in node.get("children", []):
            if child["id"] == node_id:
                return node
            found = find_parent(child, node_id)
            if found:
                return found
    return None

def walk(node, path=""):
    current = "/" if node["id"] == "root" else (path.rstrip("/") + "/" + node["name"])
    yield node, current
    if node["type"] == "folder":
        for child in node.get("children", []):
            yield from walk(child, current)

def clean_name(name):
    name = (name or "").strip()
    if not name or name in {".", ".."} or "/" in name or "\\" in name or "\x00" in name:
        return None
    return name

def unique_name(folder, name, except_id=None):
    return any(c["name"].casefold() == name.casefold() and c["id"] != except_id for c in folder.get("children", []))

@app.route("/")
def index():
    load_fs()
    return render_template("index.html")

@app.get("/api/tree")
def api_tree():
    tree = load_fs()
    return jsonify({"tree": tree, "stats": stats(tree)})

def stats(tree):
    nodes = list(walk(tree))
    return {
        "folders": sum(1 for n, _ in nodes if n["type"] == "folder"),
        "files": sum(1 for n, _ in nodes if n["type"] == "file"),
        "total": len(nodes) - 1,
        "size": sum(len(n.get("content", "").encode("utf-8")) for n, _ in nodes if n["type"] == "file")
    }

@app.post("/api/create")
def create_item():
    data = request.get_json(silent=True) or {}
    parent_id = data.get("parent_id", "root")
    name = clean_name(data.get("name"))
    kind = data.get("type")
    if not name:
        return jsonify(error="Enter a valid name without / or \\\\."), 400
    if kind not in ("file", "folder"):
        return jsonify(error="Choose file or folder."), 400
    tree = load_fs()
    parent = find_node(tree, parent_id)
    if not parent or parent["type"] != "folder":
        return jsonify(error="Destination folder was not found."), 404
    if unique_name(parent, name):
        return jsonify(error="An item with this name already exists in that folder."), 409
    now = datetime.now().isoformat(timespec="seconds")
    node = {"id": uuid.uuid4().hex[:12], "name": name, "type": kind, "parent": parent_id, "created": now, "modified": now}
    if kind == "folder":
        node["children"] = []
    else:
        node["content"] = data.get("content", "")
    parent.setdefault("children", []).append(node)
    parent["modified"] = now
    save_fs(tree)
    return jsonify(item=node, stats=stats(tree))

@app.get("/api/item/<node_id>")
def get_item(node_id):
    tree = load_fs()
    node = find_node(tree, node_id)
    if not node:
        return jsonify(error="Item not found."), 404
    return jsonify(item=node)

@app.put("/api/item/<node_id>")
def update_item(node_id):
    data = request.get_json(silent=True) or {}
    tree = load_fs()
    node = find_node(tree, node_id)
    if not node or node_id == "root":
        return jsonify(error="Item not found or cannot be changed."), 404
    now = datetime.now().isoformat(timespec="seconds")
    if "name" in data:
        name = clean_name(data.get("name"))
        parent = find_parent(tree, node_id)
        if not name:
            return jsonify(error="Enter a valid name."), 400
        if parent and unique_name(parent, name, node_id):
            return jsonify(error="An item with this name already exists in that folder."), 409
        node["name"] = name
    if node["type"] == "file" and "content" in data:
        node["content"] = str(data["content"])
    node["modified"] = now
    save_fs(tree)
    return jsonify(item=node, stats=stats(tree))

@app.delete("/api/item/<node_id>")
def delete_item(node_id):
    if node_id == "root":
        return jsonify(error="The root directory cannot be deleted."), 400
    tree = load_fs()
    parent = find_parent(tree, node_id)
    if not parent:
        return jsonify(error="Item not found."), 404
    parent["children"] = [c for c in parent["children"] if c["id"] != node_id]
    parent["modified"] = datetime.now().isoformat(timespec="seconds")
    save_fs(tree)
    return jsonify(ok=True, stats=stats(tree))

@app.post("/api/move")
def move_item():
    data = request.get_json(silent=True) or {}
    node_id, target_id = data.get("id"), data.get("target_id")
    if node_id == "root" or node_id == target_id:
        return jsonify(error="That move is not allowed."), 400
    tree = load_fs()
    node = find_node(tree, node_id)
    target = find_node(tree, target_id)
    old_parent = find_parent(tree, node_id)
    if not node or not target or not old_parent or target["type"] != "folder":
        return jsonify(error="Item or destination folder not found."), 404
    if node["type"] == "folder" and any(n["id"] == target_id for n, _ in walk(node)):
        return jsonify(error="A folder cannot be moved inside itself or one of its subfolders."), 400
    if unique_name(target, node["name"]):
        return jsonify(error="An item with this name already exists in the destination."), 409
    old_parent["children"] = [c for c in old_parent["children"] if c["id"] != node_id]
    node["parent"] = target_id
    target.setdefault("children", []).append(node)
    node["modified"] = datetime.now().isoformat(timespec="seconds")
    save_fs(tree)
    return jsonify(ok=True, stats=stats(tree))

@app.get("/api/search")
def search_items():
    q = request.args.get("q", "").strip().casefold()
    tree = load_fs()
    results = []
    if q:
        for node, path in walk(tree):
            if node["id"] != "root" and q in node["name"].casefold():
                results.append({"id": node["id"], "name": node["name"], "type": node["type"], "path": path})
    return jsonify(results=results[:100])

@app.post("/api/reset")
def reset_fs():
    tree = starter_fs()
    save_fs(tree)
    return jsonify(tree=tree, stats=stats(tree))

@app.get("/api/export")
def export_fs():
    tree = load_fs()
    memory = io.BytesIO()
    with zipfile.ZipFile(memory, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("directory-structure.json", json.dumps(tree, indent=2, ensure_ascii=False))
        for node, path in walk(tree):
            if node["type"] == "file":
                safe_path = path.lstrip("/")
                zf.writestr(safe_path, node.get("content", ""))
    memory.seek(0)
    return send_file(memory, mimetype="application/zip", as_attachment=True, download_name="file-directory-export.zip")

if __name__ == "__main__":
    load_fs()
    threading.Timer(1.2, lambda: webbrowser.open("http://127.0.0.1:5000")).start()
    app.run(debug=False, host="127.0.0.1", port=5000)
