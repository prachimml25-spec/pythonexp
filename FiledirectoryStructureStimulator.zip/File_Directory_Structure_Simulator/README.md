# FileFlow — File Directory Structure Simulator

A beginner-friendly Python Flask web project for learning file/folder organization and tree data structures.

## Features
- Create files and folders
- Edit text-file contents
- Rename, move, delete files/folders
- Search by file/folder name
- List and grid views
- Directory tree visualization
- Live counts for files, folders, items and text size
- Export the virtual workspace as a ZIP
- Persistent data saved in `data/filesystem.json`
- Responsive interface for laptop and mobile

## Requirements
- Python 3.10 or newer
- Internet connection only for the optional Google Fonts styling; the app itself runs locally

## Run on Windows
1. Extract this ZIP to a normal folder.
2. Open the extracted folder.
3. Double-click `run_windows.bat`. If Windows blocks it, use the manual steps below.
4. Wait until the terminal says Flask is running at `http://127.0.0.1:5000`.
5. Open Chrome and visit **http://127.0.0.1:5000**.
6. Keep the terminal window open while using the website. Press `Ctrl+C` in it to stop the server.

### Manual setup
Open Command Prompt in this project folder and run:

```bash
py -m pip install -r requirements.txt
py app.py
```

If `py` is not recognized, try `python -m pip install -r requirements.txt` and `python app.py`.

## Where are files saved?
This is a **virtual file system simulator**. Items you create in the browser are saved as records in:
`data/filesystem.json`

The simulated file contents are stored inside that JSON file. They are not written to arbitrary folders on your computer. To get actual files/folders on your computer, use **Export workspace**: it downloads `file-directory-export.zip`, containing a directory structure and a `directory-structure.json` description.

## How to demonstrate it
1. Explain the root folder `My Computer`.
2. Create `College Work` as a folder.
3. Open it (double-click), create `Python Notes.txt`, and type a few lines.
4. Rename it, edit its contents, and demonstrate search.
5. Use **Directory Tree** to show the hierarchy.
6. Move the file to another folder and delete a test item.
7. Export the workspace and explain the ZIP file.

## Project concept
A directory is a hierarchical structure. Each folder can contain files and subfolders. The app stores each node with an ID, name, type, parent ID, timestamps, and (for folders) a list of children. The recursive `walk()` and `find_node()` functions traverse the tree.

## Main files
- `app.py` — Flask backend and API routes
- `templates/index.html` — page layout
- `static/style.css` — styling and responsive layout
- `static/app.js` — browser interactions and API calls
- `data/filesystem.json` — automatically created persistent simulated file system
- `requirements.txt` — Python dependency
