@echo off
title FileFlow - Directory Structure Simulator
cd /d "%~dp0"
echo.
echo ============================================
echo   FileFlow - File Directory Simulator
echo ============================================
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install --user Flask
  if errorlevel 1 goto failed
  py app.py
) else (
  where python >nul 2>nul
  if errorlevel 1 goto no_python
  python -m pip install --user Flask
  if errorlevel 1 goto failed
  python app.py
)
pause
goto end
:no_python
echo Python was not found. Please install Python from https://www.python.org/downloads/
echo During setup, tick "Add Python to PATH".
start https://www.python.org/downloads/
pause
goto end
:failed
echo Setup failed. Check your internet connection and Python installation.
pause
:end
