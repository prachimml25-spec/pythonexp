FILEFLOW - PYTHON WEBSITE
=========================

Yeh project Python + Flask backend wali website hai. Website ka design HTML/CSS/JavaScript mein hai, kyunki browser mein dikhne wali website ko inki zaroorat hoti hai. Main operations aur server Python mein hain.

CHALANE KA SABSE AASAN TAREEKA (WINDOWS):
1. ZIP file par right-click > Extract All karo.
2. Extract hua folder kholo.
3. run_windows.bat par double-click karo.
4. Pehli baar Flask install hoga. Internet on rakho.
5. Browser automatically khulna chahiye. Agar nahi khulta, Chrome mein http://127.0.0.1:5000 kholo.
6. Website use karte waqt black terminal window band mat karna.
7. Band karne ke liye terminal mein Ctrl+C dabao.

Agar Python install nahi hai:
https://www.python.org/downloads/ se Python install karo. Install ke waqt "Add Python to PATH" tick karna.

DATA KAHAN SAVE HOTA HAI?
Project ke data folder ke andar filesystem.json mein. Export Workspace se ZIP bhi download kar sakte ho.

FEATURES:
Create file/folder, edit file, rename, move, delete, search, directory tree, live statistics, export ZIP.

IMPORTANT:
Website local laptop par chalti hai; internet ki zaroorat pehli baar Flask install karne ke liye hoti hai. Is project ko online publish nahi kiya gaya hai.
